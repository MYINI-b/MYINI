-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7b203.p.ssafy.io    Database: myini
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `path_variable`
--

DROP TABLE IF EXISTS `path_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `path_variable` (
  `path_variable_id` bigint NOT NULL AUTO_INCREMENT,
  `path_variable_key` varchar(255) DEFAULT NULL,
  `path_variable_type` varchar(255) DEFAULT NULL,
  `api_id` bigint DEFAULT NULL,
  PRIMARY KEY (`path_variable_id`),
  KEY `FK2g09go9l7fufc6okircpirphr` (`api_id`),
  CONSTRAINT `FK2g09go9l7fufc6okircpirphr` FOREIGN KEY (`api_id`) REFERENCES `api` (`api_id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `path_variable`
--

LOCK TABLES `path_variable` WRITE;
/*!40000 ALTER TABLE `path_variable` DISABLE KEYS */;
INSERT INTO `path_variable` VALUES (2,'userid','Long',8),(6,'pillid','Long',21),(11,'projectid','Long',38),(12,'projectid','Long',39),(13,'projectid','Long',53),(14,'projectid','Long',61),(15,'projectid','Long',62),(16,'apicontrollerid','Long',40),(17,'apicontrollerid','Long',41),(18,'apicontrollerid','Long',42),(19,'apicontrollerid','Long',43),(20,'apiid','Long',44),(21,'apiid','Long',45),(22,'apiid','Long',46),(23,'apiid','Long',47),(24,'apiid','Long',50),(25,'apiid','Long',54),(26,'pathvariableid','Long',48),(27,'pathvariableid','Long',49),(28,'querystringid','Long',51),(29,'querystringid','Long',52),(30,'dtoid','Long',55),(31,'dtoid','Long',56),(32,'dtoid','Long',57),(33,'dtoid','Long',58),(34,'dtoitemid','Long',59),(35,'dtoitemid','Long',60),(49,'projectid','Long',67),(50,'projectid','Long',68),(51,'requirementid','Long',69),(52,'requirementid','Long',70),(53,'requirementid','Long',71),(54,'requirementid','Long',72),(55,'requirementid','Long',73),(56,'requirementid','Long',74),(57,'requirementid','Long',75),(58,'requirementid','Long',76),(59,'projectid','Long',77),(60,'projectid','Long',78),(61,'projectid','Long',79),(70,'projectid','Long',91),(72,'projectid','Long',93),(82,'dd','Long',115),(89,'projectid','Long',150),(95,'projectid','Long',153),(96,'projectid','Long',154),(98,'projectid','Long',92),(99,'start','NORMAL',92),(100,'myini','NORMAL',95),(101,'downloads','NORMAL',95),(102,'fcm','NORMAL',156),(103,'ㅇㅇ','NORMAL',157),(104,'ㅇ','NORMAL',157),(105,'ㅇ','NORMAL',157),(106,'ㅇ','NORMAL',157),(107,'ㅇ','NORMAL',157),(108,'ㅇ','NORMAL',157),(110,'exercise','NORMAL',159),(111,'bookmark','NORMAL',159),(112,'exercise_id','Integer',160),(113,'bookmark','NORMAL',162),(114,'pill','NORMAL',162),(115,'pill','NORMAL',163),(116,'pill_id','Integer',163),(117,'inbody','NORMAL',164),(118,'logout','NORMAL',165),(119,'event','NORMAL',166),(120,'calendar_date','Integer',168),(121,'calendar_id','Integer',170),(122,'calendar_id','Integer',171),(123,'calendar_id','Integer',172),(126,'controllers','NORMAL',39),(129,'controllers','NORMAL',38),(132,'jiraacount','NORMAL',150),(140,'profile','NORMAL',208),(141,'jiraemail','NORMAL',210),(142,'crew','NORMAL',211);
/*!40000 ALTER TABLE `path_variable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-19 14:23:35
