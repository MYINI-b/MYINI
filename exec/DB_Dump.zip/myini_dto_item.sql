-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7b203.p.ssafy.io    Database: myini
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dto_item`
--

DROP TABLE IF EXISTS `dto_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dto_item` (
  `dto_item_id` bigint NOT NULL AUTO_INCREMENT,
  `dto_is_list` varchar(255) DEFAULT NULL,
  `dto_item_name` varchar(255) DEFAULT NULL,
  `dto_id` bigint DEFAULT NULL,
  `dto_class_type` bigint DEFAULT NULL,
  `primitive_id` bigint DEFAULT NULL,
  PRIMARY KEY (`dto_item_id`),
  KEY `FKcxfw59l4fb1tv805fud6hqmgx` (`dto_id`),
  KEY `FK2n0d5vx46rfmaunmlvi028tuh` (`dto_class_type`),
  KEY `FKqcxxhhfmc34jmww536dg7li2p` (`primitive_id`),
  CONSTRAINT `FK2n0d5vx46rfmaunmlvi028tuh` FOREIGN KEY (`dto_class_type`) REFERENCES `dto` (`dto_id`),
  CONSTRAINT `FKcxfw59l4fb1tv805fud6hqmgx` FOREIGN KEY (`dto_id`) REFERENCES `dto` (`dto_id`),
  CONSTRAINT `FKqcxxhhfmc34jmww536dg7li2p` FOREIGN KEY (`primitive_id`) REFERENCES `primitive` (`primitive_id`)
) ENGINE=InnoDB AUTO_INCREMENT=468 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dto_item`
--

LOCK TABLES `dto_item` WRITE;
/*!40000 ALTER TABLE `dto_item` DISABLE KEYS */;
INSERT INTO `dto_item` VALUES (72,'N','id',25,NULL,2),(73,'N','relatedItemId',25,NULL,2),(74,'N','name',25,NULL,9),(75,'Y','type',25,NULL,9),(104,'N','apiControllerName',37,NULL,9),(105,'N','apiControllerBaseUrl',37,NULL,9),(106,'N','apiControllerDescription',37,NULL,9),(107,'N','apiControllerName',38,NULL,9),(108,'Y','test1',38,NULL,9),(109,'N','apiControllerDescription',38,NULL,9),(110,'N','apiName',39,NULL,9),(111,'N','apiDescription',39,NULL,9),(112,'N','apiUrl',39,NULL,9),(113,'N','apiMethod',39,NULL,9),(114,'N','apiCode',39,NULL,9),(115,'N','apiMethodName',39,NULL,9),(116,'N','apiName',40,NULL,9),(117,'N','apiDescription',40,NULL,9),(118,'N','apiUrl',40,NULL,9),(119,'N','apiMethod',40,NULL,9),(120,'N','apiCode',40,NULL,9),(121,'N','apiMethodName',40,NULL,9),(122,'N','pathVariableKey',41,NULL,9),(123,'N','pathVariableType',41,NULL,9),(124,'N','pathVariableKey',42,NULL,9),(125,'N','pathVariableType',42,NULL,9),(126,'N','queryStringKey',43,NULL,9),(127,'N','queryStringType',43,NULL,9),(128,'N','queryStringKey',44,NULL,9),(129,'N','queryStringType',44,NULL,9),(130,'N','dtoName',45,NULL,9),(131,'N','dtoType',45,NULL,9),(132,'N','dtoIsList',45,NULL,9),(133,'N','dtoName',46,NULL,9),(134,'N','dtoType',46,NULL,9),(135,'N','dtoIsList',46,NULL,9),(136,'N','dtoName',47,NULL,9),(137,'N','dtoType',47,NULL,9),(138,'N','dtoIsList',47,NULL,9),(139,'N','dtoItemName',48,NULL,9),(140,'N','dtoClassType',48,NULL,2),(141,'N','dtoPrimitiveType',48,NULL,2),(142,'N','dtoIsList',48,NULL,9),(143,'N','dtoItemName',49,NULL,9),(144,'N','dtoClassType',49,NULL,2),(145,'N','dtoPrimitiveType',49,NULL,2),(146,'N','dtoIsList',49,NULL,9),(147,'N','apiControllerId',50,NULL,2),(148,'N','apiControllerId',51,NULL,2),(149,'N','apiControllerName',51,NULL,9),(150,'N','apiControllerId',52,NULL,2),(151,'N','apiControllerName',52,NULL,9),(152,'N','apiControllerBaseUrl',52,NULL,9),(153,'N','apiControllerDescription',52,NULL,9),(154,'Y','apiResponses',52,53,NULL),(155,'N','apiId',53,NULL,2),(156,'N','apiName',53,NULL,9),(157,'N','apiDescription',53,NULL,9),(158,'N','apiUrl',53,NULL,9),(159,'N','apiMethod',53,NULL,9),(160,'N','apiCode',53,NULL,9),(161,'N','apiMethodName',53,NULL,9),(162,'N','apiResponse',54,53,NULL),(163,'Y','pathVariableResponses',54,55,NULL),(164,'Y','queryStringResponses',54,56,NULL),(165,'Y','dtoResponses',54,59,NULL),(166,'N','pathVariableId',55,NULL,2),(167,'N','pathVariableKey',55,NULL,9),(168,'N','pathVariableType',55,NULL,9),(169,'N','queryStringId',56,NULL,2),(170,'N','queryStringKey',56,NULL,9),(171,'N','queryStringType',56,NULL,9),(172,'N','dtoId',57,NULL,2),(173,'N','dtoId',58,NULL,2),(174,'N','dtoId',59,NULL,2),(175,'N','dtoName',59,NULL,9),(176,'N','dtoType',59,NULL,9),(177,'Y','dtoItemResponses',59,60,NULL),(178,'N','dtoIsList',59,NULL,9),(179,'N','dtoItemId',60,NULL,2),(180,'N','requirementCategoryId',74,NULL,2),(181,'N','dtoItemName',60,NULL,9),(182,'N','categoryName',74,NULL,9),(183,'N','dtoClassTypeId',60,NULL,2),(184,'N','categoryColor',74,NULL,9),(185,'N','dtoPrimitiveTypeId',60,NULL,2),(186,'N','dtoIsList',60,NULL,9),(187,'N','dtoClassTypeName',60,NULL,9),(188,'N','dtoPrimitiveTypeName',60,NULL,9),(189,'N','requirementId',63,NULL,2),(190,'N','requirementCategoryDto',63,74,NULL),(191,'Y','primitiveTypeResponses',61,35,NULL),(192,'N','requirementName',63,NULL,9),(193,'N','requirementContent',63,NULL,9),(194,'Y','classTypeResponses',61,36,NULL),(195,'N','requirementPart',63,NULL,9),(196,'N','memberNickName',63,NULL,9),(197,'N','memberJiraEmail',63,NULL,9),(198,'N','requirementPriority',63,NULL,1),(199,'N','requirementStoryPoint',63,NULL,4),(200,'N','apiControllerId',62,NULL,2),(201,'N','apiControllerName',62,NULL,9),(202,'N','categoryId',64,NULL,2),(203,'N','apiControllerBaseUrl',62,NULL,9),(204,'N','apiControllerDescription',62,NULL,9),(205,'N','requirementName',65,NULL,9),(206,'N','requirementContent',66,NULL,9),(207,'N','requirementPart',67,NULL,9),(208,'Y','apiInfoResponses',62,54,NULL),(209,'N','memberName',68,NULL,9),(210,'N','requirementPriority',69,NULL,1),(211,'N','requirementStoryPoint',70,NULL,4),(212,'N','primitiveId',35,NULL,2),(213,'N','primitiveName',35,NULL,9),(214,'N','dtoId',36,NULL,2),(215,'N','dtoName',36,NULL,9),(216,'N','requirementCategoryId',71,NULL,2),(217,'N','categoryName',71,NULL,9),(218,'N','categoryColor',71,NULL,9),(219,'N','categoryName',72,NULL,9),(220,'N','categoryColor',72,NULL,9),(221,'N','requirementCategoryId',73,NULL,2),(228,'N','isPossible',76,NULL,8),(230,'N','contents',76,NULL,9),(238,'N','fileCategory',85,NULL,9),(239,'N','fileName',85,NULL,9),(240,'N','contents',85,NULL,9),(241,'N','springBasePath',86,NULL,9),(242,'N','springType',86,NULL,9),(243,'N','springLanguage',86,NULL,9),(244,'N','springPlatformVersion',86,NULL,9),(245,'N','springPackaging',86,NULL,9),(246,'N','springJvmVersion',86,NULL,9),(247,'N','springGroupId',86,NULL,9),(248,'N','springArtifactId',86,NULL,9),(249,'N','springName',86,NULL,9),(250,'N','springDescription',86,NULL,9),(251,'N','springPackageName',86,NULL,9),(252,'N','springDependencyName',86,NULL,9),(322,'N','test2',119,NULL,4),(323,'N','test',119,NULL,9),(333,'N','test2',121,NULL,9),(359,'N','2',147,NULL,1),(360,'N','2',148,121,NULL),(401,'N','jiraIds',197,NULL,9),(402,'N','jiraApiKey',197,NULL,9),(403,'N','fcmToken',204,NULL,9),(404,'N','userProfileNickname',210,NULL,9),(405,'N','userProfileBirthday',210,NULL,9),(406,'N','userProfileGender',210,NULL,9),(407,'N','exercisePurposeId',210,NULL,1),(408,'N','exerciseTimes',210,NULL,1),(409,'N','userProfileHeight',210,NULL,4),(410,'N','userProfileWeight',210,NULL,4),(411,'N','userProfileFat',210,NULL,4),(412,'N','userProfileSkeleton',210,NULL,4),(413,'N','userProfileWater',210,NULL,4),(418,'N','relatedItemId',212,NULL,1),(419,'N','id',212,NULL,1),(420,'N','name',212,NULL,9),(421,'Y','type',212,NULL,9),(422,'N','exerciseDoing',214,NULL,9),(423,'N','exerciseBookmark',214,NULL,9),(424,'N','exerciseLike',214,NULL,9),(425,'N','userProfileBirthday',206,NULL,9),(426,'N','userProfileGender',206,NULL,9),(427,'N','exercisePurposeId',206,NULL,1),(428,'N','exerciseTimes',206,NULL,1),(429,'N','name',218,NULL,9),(430,'N','rating',218,NULL,4),(431,'N','id',218,NULL,1),(432,'N','img',218,NULL,9),(433,'N','relatedItemId',218,NULL,1),(434,'N','pillBookmark',220,NULL,9),(435,'N','pillTaking',220,NULL,9),(436,'N','userProfileSkeleton',221,NULL,4),(437,'N','userProfileWeight',221,NULL,4),(438,'N','userProfileHeight',221,NULL,4),(439,'N','userProfileWater',221,NULL,4),(440,'N','userProfileFat',221,NULL,4),(441,'N','body',226,NULL,1),(442,'N','user',227,208,NULL),(443,'N','user',229,208,NULL),(444,'N','a',208,NULL,9),(445,'N','i',87,NULL,2),(446,'N','d',87,NULL,2);
/*!40000 ALTER TABLE `dto_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-19 14:23:34
