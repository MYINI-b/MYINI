-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7b203.p.ssafy.io    Database: myini
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_controller`
--

DROP TABLE IF EXISTS `api_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_controller` (
  `api_controller_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `api_controller_base_url` varchar(255) DEFAULT NULL,
  `api_controller_description` varchar(255) DEFAULT NULL,
  `api_controller_name` varchar(255) DEFAULT NULL,
  `project_id` bigint DEFAULT NULL,
  PRIMARY KEY (`api_controller_id`),
  KEY `FKq8u590fajp02jduelty3pivtw` (`project_id`),
  CONSTRAINT `FKq8u590fajp02jduelty3pivtw` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_controller`
--

LOCK TABLES `api_controller` WRITE;
/*!40000 ALTER TABLE `api_controller` DISABLE KEYS */;
INSERT INTO `api_controller` VALUES (2,'2022-11-01 13:26:59','2022-11-01 13:26:59','/users','회원관리를 위한 컨트롤러','User',2),(4,'2022-11-02 15:28:16','2022-11-02 15:28:16','/exercises','운동 관련 기능','Exercise',3),(5,'2022-11-02 15:28:49','2022-11-02 15:28:49','/pills','영양제 관련 기능','Pill',3),(6,'2022-11-03 10:41:31','2022-11-03 11:02:13','/keyword','키워드 관련 기능','Keyword',4),(7,'2022-11-03 11:02:49','2022-11-03 11:02:49','/dykclub','두유노클럽 관련기능','DYKClub',4),(19,'2022-11-08 11:02:33','2022-11-08 11:02:33','/apidocs','프로젝트에서 사용될 API관련 기능','ApiDocs',15),(22,'2022-11-08 11:04:38','2022-11-18 15:07:57','/requirementdocs','요구사항 명세서 관련 기능입니다.','RequirementDocs',15),(23,'2022-11-08 11:05:26','2022-11-08 11:05:26','/initializers','프로젝트 이니셜라이저 관련 기능','Initializer',15),(35,'2022-11-17 11:31:44','2022-11-18 15:20:11','/jiras','지라 관련 기능입니다.!','Jira',15),(52,'2022-11-17 16:28:26','2022-11-17 16:28:26','/gterd','geat','gaet',97),(53,'2022-11-17 16:29:07','2022-11-17 16:29:07','/hsrdtg','hrts','bdsr',97),(94,'2022-11-17 16:59:55','2022-11-17 16:59:55','/users','회원관리','User',99),(96,'2022-11-17 17:00:24','2022-11-17 17:00:24','/pills','영양제','Pills',99),(97,'2022-11-17 20:03:55','2022-11-17 20:03:55','/calendars','캘린더','CALENDAR',99),(136,'2022-11-19 14:18:40','2022-11-19 14:18:40','/members','회원관련 기능입니다.','Member',15);
/*!40000 ALTER TABLE `api_controller` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-19 14:23:39
