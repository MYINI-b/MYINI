-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7b203.p.ssafy.io    Database: myini
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dto`
--

DROP TABLE IF EXISTS `dto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dto` (
  `dto_id` bigint NOT NULL AUTO_INCREMENT,
  `dto_name` varchar(255) DEFAULT NULL,
  `dto_type` varchar(255) DEFAULT NULL,
  `api_id` bigint DEFAULT NULL,
  `dto_is_list` varchar(255) DEFAULT NULL,
  `project_id` bigint DEFAULT NULL,
  PRIMARY KEY (`dto_id`),
  KEY `FKf14wn0fku8i0gj3tse1lvfdv5` (`api_id`),
  KEY `FK271g2i8vic29hn9qjv7pqtn0w` (`project_id`),
  CONSTRAINT `FK271g2i8vic29hn9qjv7pqtn0w` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`),
  CONSTRAINT `FKf14wn0fku8i0gj3tse1lvfdv5` FOREIGN KEY (`api_id`) REFERENCES `api` (`api_id`)
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dto`
--

LOCK TABLES `dto` WRITE;
/*!40000 ALTER TABLE `dto` DISABLE KEYS */;
INSERT INTO `dto` VALUES (12,'ExerciseCategoryResponse ','RESPONSE',17,'N',3),(13,'ExercisePartResponse ','RESPONSE',18,'N',3),(14,'ExerciseInfoResponse ','RESPONSE',19,'N',3),(15,'PillKeywordInfoResponse ','RESPONSE',20,'N',3),(16,'PillInfoResponse ','RESPONSE',21,'N',3),(25,'UserExerciseResponse','RESPONSE',17,'N',3),(35,'PrimitiveTypeResponse','DTO',NULL,'N',15),(36,'ClassTypeResponse','DTO',NULL,'N',15),(37,'CreateApiControllerRequest','REQUEST',38,'N',NULL),(38,'UpdateApiControllerRequest','REQUEST',41,'N',NULL),(39,'CreateApiRequest','REQUEST',43,'N',NULL),(40,'UpdateApiRequest','REQUEST',44,'N',NULL),(41,'CreatePathVariableRequest','REQUEST',47,'N',NULL),(42,'UpdatePathVariableRequest','REQUEST',48,'N',NULL),(43,'CreateQueryStringRequest','REQUEST',50,'N',NULL),(44,'UpdateQueryStringRequest','REQUEST',51,'N',NULL),(45,'CreateDtoRequest','REQUEST',53,'N',NULL),(46,'CreateDtoRequest','REQUEST',54,'N',NULL),(47,'UpdateDtoRequest','REQUEST',55,'N',NULL),(48,'CreateDtoItemRequest','REQUEST',58,'N',NULL),(49,'UpdateDtoItemRequest','REQUEST',59,'N',NULL),(50,'ApiControllerCreateResponse','RESPONSE',38,'N',NULL),(51,'ApiControllerListResponse','RESPONSE',39,'Y',NULL),(52,'ApiControllerResponse','RESPONSE',40,'N',NULL),(53,'ApiResponse','RESPONSE',43,'N',NULL),(54,'ApiInfoResponse','RESPONSE',46,'N',NULL),(55,'PathVariableResponse','RESPONSE',47,'N',NULL),(56,'QueryStringResponse','RESPONSE',50,'N',NULL),(57,'DtoCreateResponse','RESPONSE',53,'N',NULL),(58,'DtoCreateResponse','RESPONSE',54,'N',NULL),(59,'DtoResponse','RESPONSE',57,'N',NULL),(60,'DtoItemResponse','RESPONSE',58,'N',NULL),(61,'TypeListResponse','RESPONSE',61,'N',NULL),(62,'ProjectInfoListResponse','RESPONSE',62,'Y',NULL),(63,'RequirementListResponse','RESPONSE',67,'Y',NULL),(64,'RequirementCategoryUpdateRequest','REQUEST',69,'N',NULL),(65,'RequirementNameUpdateRequest','REQUEST',70,'N',NULL),(66,'RequirementContentUpdateRequest','REQUEST',71,'N',NULL),(67,'RequirementPartUpdateRequest','REQUEST',72,'N',NULL),(68,'RequirementMemberUpdateRequest','REQUEST',73,'N',NULL),(69,'RequirementPriorityUpdateRequest','REQUEST',74,'N',NULL),(70,'RequirementStoryPointUpdateRequest','REQUEST',75,'N',NULL),(71,'RequirementCategoryListResponse','RESPONSE',77,'Y',NULL),(72,'RequirementCategoryCreateRequest','REQUEST',78,'N',NULL),(73,'RequirementCategoryCreateResponse','RESPONSE',78,'N',NULL),(74,'RequirementCategoryResponse','DTO',NULL,'N',15),(76,'InitializerPossibleResponse','RESPONSE',91,'N',NULL),(83,'InitializerRequest','REQUEST',92,'N',NULL),(85,'PreviewResponse','RESPONSE',93,'Y',NULL),(86,'InitializerRequest','REQUEST',93,'N',NULL),(87,'ProjectMemberResponse','DTO',NULL,'N',15),(119,'TEST','DTO',NULL,'N',3),(121,'test2','DTO',NULL,'N',3),(147,'1RequestDto','REQUEST',106,'N',NULL),(148,'1ResponseDto','RESPONSE',106,'N',NULL),(165,'UNTITLED','DTO',NULL,'N',3),(166,'RequestDtobb','REQUEST',115,'N',NULL),(167,'ResponseDtobb','RESPONSE',115,'N',NULL),(197,'RequestDtoupdateJiraAccount','REQUEST',150,'N',NULL),(198,'ResponseDtoupdateJiraAccount','RESPONSE',150,'N',NULL),(199,'RequestDtofindJiraProjectList','REQUEST',153,'N',NULL),(200,'ResponseDtofindJiraProjectList','RESPONSE',153,'N',NULL),(201,'RequestDtojiraCreateIssue','REQUEST',154,'N',NULL),(202,'ResponseDtojiraCreateIssue','RESPONSE',154,'N',NULL),(204,'createFcmTokenRequestDto','REQUEST',156,'N',NULL),(205,'createFcmTokenResponseDto','RESPONSE',156,'N',NULL),(206,'createUserProfileRequestDto','REQUEST',157,'N',NULL),(207,'createUserProfileResponseDto','RESPONSE',157,'N',NULL),(208,'User','DTO',NULL,'N',99),(209,'findUserRequestDto','REQUEST',158,'N',NULL),(210,'findUserResponseDto','RESPONSE',158,'N',NULL),(211,'findBookmarkExerciseByUserRequestDto','REQUEST',159,'N',NULL),(212,'findBookmarkExerciseByUserResponseDto','RESPONSE',159,'Y',NULL),(213,'findByExerciseRequestDto','REQUEST',160,'N',NULL),(214,'findByExerciseResponseDto','RESPONSE',160,'N',NULL),(217,'findBookmarkPillByUserRequestDto','REQUEST',162,'N',NULL),(218,'findBookmarkPillByUserResponseDto','RESPONSE',162,'Y',NULL),(219,'findByPillRequestDto','REQUEST',163,'N',NULL),(220,'findByPillResponseDto','RESPONSE',163,'N',NULL),(221,'updateUserInbodyRequestDto','REQUEST',164,'N',NULL),(222,'updateUserInbodyResponseDto','RESPONSE',164,'N',NULL),(223,'logoutRequestDto','REQUEST',165,'N',NULL),(224,'logoutResponseDto','RESPONSE',165,'N',NULL),(225,'createUserEventRequestDto','REQUEST',166,'N',NULL),(226,'createUserEventResponseDto','RESPONSE',166,'N',NULL),(227,'findListByCalendarDateRequestDto','REQUEST',167,'N',NULL),(228,'findListByCalendarDateResponseDto','RESPONSE',167,'N',NULL),(229,'findByCalendarDateRequestDto','REQUEST',168,'N',NULL),(230,'findByCalendarDateResponseDto','RESPONSE',168,'N',NULL),(231,'createCalendarRequestDto','REQUEST',169,'N',NULL),(232,'createCalendarResponseDto','RESPONSE',169,'N',NULL),(233,'updateCalendarRequestDto','REQUEST',170,'N',NULL),(234,'updateCalendarResponseDto','RESPONSE',170,'N',NULL),(235,'deleteCalendarRequestDto','REQUEST',171,'N',NULL),(236,'deleteCalendarResponseDto','RESPONSE',171,'N',NULL),(237,'updateCalendarCompleteRequestDto','REQUEST',172,'N',NULL),(238,'updateCalendarCompleteResponseDto','RESPONSE',172,'N',NULL),(285,'RequestDto','REQUEST',208,'N',NULL),(286,'ResponseDto','RESPONSE',208,'N',NULL),(287,'RequestDto','REQUEST',209,'N',NULL),(288,'ResponseDto','RESPONSE',209,'N',NULL),(289,'RequestDto','REQUEST',210,'N',NULL),(290,'ResponseDto','RESPONSE',210,'N',NULL),(291,'findCrewByIdRequestDto','REQUEST',211,'N',NULL),(292,'findCrewByIdResponseDto','RESPONSE',211,'N',NULL);
/*!40000 ALTER TABLE `dto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-19 14:23:37
