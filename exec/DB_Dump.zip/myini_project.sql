-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7b203.p.ssafy.io    Database: myini
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `project_id` bigint NOT NULL AUTO_INCREMENT,
  `project_description` varchar(255) DEFAULT NULL,
  `project_figma_url` varchar(255) DEFAULT NULL,
  `project_finished_date` date DEFAULT NULL,
  `project_github_url` varchar(255) DEFAULT NULL,
  `project_img` varchar(255) DEFAULT NULL,
  `project_jira_url` varchar(255) DEFAULT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_notion_url` varchar(255) DEFAULT NULL,
  `project_started_date` date DEFAULT NULL,
  `jira_api_key` varchar(255) DEFAULT NULL,
  `jira_id` varchar(255) DEFAULT NULL,
  `jira_project_key` varchar(255) DEFAULT NULL,
  `jira_domain` varchar(255) DEFAULT NULL,
  `jira_project_id` varchar(255) DEFAULT NULL,
  `jira_project_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,'first project',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'프로젝트 이니셜라이징프로젝트',NULL,NULL,'https://lab.ssafy.com/s07-final/S07P31B203',NULL,NULL,'myini111',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'운동 및 영양제 추천 서비스','https://www.figma.com/file/LcVduitU7Hq54jPQzTWCBp/%ED%8A%B9%ED%99%94HP?node-id=2%3A2','2022-10-07','https://lab.ssafy.com/s07-bigdata-recom-sub2/S07P22B203','6034d09c-75ee-4b2f-85b9-592d76037423.png','https://jira.ssafy.com/secure/RapidBoard.jspa?rapidView=13025&projectKey=S07P22B203&view=reporting&chart=burndownChart&sprint=25902','shealth and pill','123','2022-08-31','ioMpUuv5sNoZZRzeiyKtD124','rladnqls98@gmail.com','MYINI','myini','10000',NULL),(4,'전 세계속에서의 한국의 인기 키워드를 알아보는 서비스','https://www.figma.com/file/AEjAWkCo4s6JkpJhKb8XqZ/Doyouknow%3F','2022-11-17','https://lab.ssafy.com/s07-bigdata-dist-sub2/S07P22B208','bc9e7e4d-b1ab-45ba-ad8b-1d639ace3f18.png','https://ssafy.atlassian.net/jira/software/c/projects/S07P31B203','DoYouKnow','https://www.notion.so/8-d1f1350d842a4968b920596ea5742efe','2022-10-15','ioMpUuv5sNoZZRzeiyKtD124','rladnqls98@gmail.com','2','ssafy','2',NULL),(5,'프로젝트 설명','프로젝트 URL',NULL,'프로젝트 URL',NULL,'프로젝트 URL','프로젝트 이름','프로젝트 URL',NULL,NULL,NULL,'1',NULL,'1',NULL),(15,'','https://www.figma.com/file/uWa8mapSFf1hpfZB3GUhVQ/MyINI?node-id=0%3A1','2022-11-19','https://lab.ssafy.com/s07-final/S07P31B203','72df5988-e444-4cc4-bed1-ce6e7d4674e1.png','https://lab.ssafy.com/s07-final/S07P31B203','Untitled','https://flawless-yarn-6c8.notion.site/SSAFY-63a8275c69fd47a09f7db03750507aa2','2022-11-19','ioMpUuv5sNoZZRzeiyKtD124','rladnqls98@gmail.com','MYINI','myini','10000',NULL),(37,'사용자 맞춤 기사를 통한 더 스마트한 영어 공부, 뉴스터디','',NULL,'','fe4f9dba-7fd5-4fa9-bf75-7428668f987e.png','','NEWSTUDY','',NULL,'ioMpUuv5sNoZZRzeiyKtD124','rladnqls98@gmail.com','MYINI','myini','10000',NULL),(78,NULL,NULL,NULL,NULL,NULL,NULL,'Untitled',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(97,'bdfgbsdr','',NULL,'',NULL,'','Untitled','',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(99,'건강한 삶을 위하여!','','2022-11-20','','2b229c5e-9422-4b91-a9b4-683e58d7752d.png','','HP(Health & Pills)','',NULL,'ioMpUuv5sNoZZRzeiyKtD124','rladnqls98@gmail.com','MYINI','myini','10000',NULL),(101,NULL,NULL,NULL,NULL,NULL,NULL,'Untitled',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-19 14:23:39
