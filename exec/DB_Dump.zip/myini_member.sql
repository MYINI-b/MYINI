-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7b203.p.ssafy.io    Database: myini
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `member_email` varchar(255) NOT NULL,
  `member_name` varchar(255) NOT NULL,
  `member_nickname` varchar(255) NOT NULL,
  `member_profile_img` varchar(255) DEFAULT NULL,
  `member_provider` varchar(255) NOT NULL,
  `member_provider_id` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `member_jira_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (2,'2022-10-31 02:33:35','2022-10-31 02:33:35','test@test.com','으아악','오오옥',NULL,'google','testtest','ROLE_USER',NULL),(3,NULL,'2022-11-14 17:55:47','rladnqls98@gmail.com','google_103768904098315821113','김우빈','https://lh3.googleusercontent.com/a/ALm5wu2eMzSkcEHsERUnRSN_wn3jJRFyMOdUSrRZaty5eA=s96-c','google','103768904098315821113','ROLE_USER','rladnqls98@gmail.com'),(5,NULL,'2022-11-14 08:32:44','lsuksa0315@gmail.com','google_118133493684523647844','이성재','https://lh3.googleusercontent.com/a/ALm5wu2PqdsJNMpAP3aA-9PkT2-Z85xGDyTaVKIgm4gB=s96-c','google','118133493684523647844','ROLE_USER','lsuksa1@naver.com'),(6,'2022-11-01 11:13:47','2022-11-14 10:41:52','gksekqls9808@gmail.com','google_116580875106305089134','한다빈','https://lh3.googleusercontent.com/a/ALm5wu1l25HFBPNnRQ_B5dkU_czpsGPGvZ9MhAd7vbv1=s96-c','google','116580875106305089134','ROLE_USER','gksekqls9808@naver.com'),(8,'2022-11-03 08:54:55','2022-11-14 08:41:32','roadcheers@gmail.com','google_105302229002842288590','배건길','https://lh3.googleusercontent.com/a/ALm5wu2nRY7AklmVGHiDBS44o0H0iBqXYsdk-dreNMXZ=s96-c','google','105302229002842288590','ROLE_USER','wmf3362@naver.com'),(10,'2022-11-08 10:30:38','2022-11-15 14:40:38','hys6078@gmail.com','google_112128132791694299413','한윤석','https://lh3.googleusercontent.com/a/ALm5wu07DfujzXtfIhqJROLvKeqNHWofA_17zVw5z3eR=s96-c','google','112128132791694299413','ROLE_USER','hys6078@naver.com'),(12,'2022-11-11 11:29:18','2022-11-14 04:16:29','rkarud1234@gmail.com','google_114182303686473629230','김갑경','https://lh3.googleusercontent.com/a/ALm5wu2fgNFmJf83sBtc1TVY-8MHEqEj2hnZczAC4q7v=s96-c','google','114182303686473629230','ROLE_USER','rkarud1234@koreatech.ac.kr'),(13,'2022-11-16 23:12:51','2022-11-16 23:12:51','rjsrlfdlek@gmail.com','google_109527134739144239468','ma “gunze” g','https://lh3.googleusercontent.com/a/ALm5wu2qO1k03Pbxmfwp9nyi8x8zomuBQFnflGTsxE4a=s96-c','google','109527134739144239468','ROLE_USER',NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-19 14:23:40
